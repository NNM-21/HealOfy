import React from "react";
import AppointmentForm from "../Components/AppointmentForm";

function Appointment() {
  return <AppointmentForm />;
}

export default Appointment;
