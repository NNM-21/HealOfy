import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../Styles/Loginsignup.css';

export const Loginsignup = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignUp = (e) => {
    e.preventDefault();
    // Perform sign-up logic here
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Password:', password);
  };

  return (
    <>
      <div className="login">
        <div className="login-container">
          <h1>Sign Up</h1>
          <form onSubmit={handleSignUp}>
            <div className="login-fields">
              <input
                type="text"
                placeholder="Your Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
              <input
                type="email"
                placeholder="Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <button type="submit">Continue</button>
          </form>
          <p className="login-login">
            Already have an account? <Link to="/signin"><button>Login here</button></Link>
          </p>
          <div className="login-agree">
            <input type="checkbox" name="" id="" />
            <p>By continuing, I agree to the terms of use & privacy policy.</p>
            <div className='doctor'>
              <p className='doctor-signin'>Signup as Doctor? <Link to='/docsignup'><button>Signup here</button></Link></p>
            </div>
          </div>
          <Link to={'/Healofy'}><button>Back to Home</button></Link>
        </div>
      </div>
    </>
  );
};

export default Loginsignup;
