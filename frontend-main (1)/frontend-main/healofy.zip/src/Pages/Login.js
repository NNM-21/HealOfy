import React from 'react';
import '../Styles/Login.css';
import { Link } from 'react-router-dom';

const Login = () => {
    return (
        <div className="login">
            <div className="login-container">
                <h1>Sign In</h1>
                <div className="login-fields">
                    <input type="email" placeholder='Email Address' />
                    <input type="password" placeholder='Password' />
                </div>
                <button>Sign In</button>
                <p className="login-signup">Don't have an account? <Link to='/signup'><button>Sign Up here</button></Link></p>  
            
            <div className='doctor-container'>
                <div className='doctor'>
                    <p className='doctor-signin'>Login as Doctor? <Link to='/doclogin'><button>Login in here</button></Link></p>
                    <p className='doctor-signin'>Login as Admin? <Link to='/adlogin'><button>Login in here</button></Link></p>
                </div>
                <Link to={'/Healofy'}><button>Back to Home</button></Link>
            </div>
        </div>
        </div>
    );
}

export default Login;
