import React from 'react'
import '../Styles/Docsignup.css'
import { Link } from 'react-router-dom'
export const Docsignup = () => {
    return (
    <div className="login">
     <div className="login-container">
        <h1>Doctor Sign Up</h1>
        <div className="login-fields">
            <input type="text" placeholder='Your Name' />
            <input type="email" placeholder='Email Address' />
            <input type="password" placeholder='Password' />
            </div>
          <button>Continue</button>
          <p className="login-login">Already have an account ? <Link to='/doclogin'><button>Login here</button></Link></p>  
          <div className="login-agree">
            <input type="checkbox" name="" id="" />
            <p>By continuing, I agree to the terms of use & privacy policy.</p>
          </div>
          <Link to={'/Healofy'}><button>Back to Home</button></Link>
     </div>
    </div>
    )
}

export default Docsignup