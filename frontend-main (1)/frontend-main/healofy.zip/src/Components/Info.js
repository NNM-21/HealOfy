import React from "react";
import InformationCard from "./InformationCard";
import "../Styles/Info.css";
import { Link } from "react-router-dom";

function Info() {
  return (
    <div className="info-section" id="services">
      <div className="info-title-content">
        <h3 className="info-title">
          <span>What We Do</span>
        </h3>
        <p className="info-description">
          We bring self help to your convenience, offering a comprehensive
          range of on-demand self care services tailored to your needs. Our
          platform allows you to connect with experienced online doctors who
          provide expert medical advice, or you can use the app to just feel better.
        </p>
      </div>
      <div className="info-cards-content">
       <InformationCard
          title="Emergency Care"
          description="Our Emergency Care service is designed to be your reliable support
            in critical situations. Whether it's a sudden medical concern that requires immediate attention, our team of
            dedicated self help professionals is available 24/7 to provide
            prompt and efficient care."
     
        />

       <InformationCard
          title="Chat with experts"
          description="We value the time and well-being of our patients and want them to only spend their tiem correctly
          and thus they can chat with the expert psychiatricts that are available with us at Healofy!"
      
        />

        <InformationCard
          title="Enjoy the positive community"
          description="The healofy community is a positive platform where we engage the users with jokes, blogs, posts, forum of 
          question and answers so that they can get better by interacting with all of them."
     
        /> 
      </div>
    </div>
  );
}

export default Info;
