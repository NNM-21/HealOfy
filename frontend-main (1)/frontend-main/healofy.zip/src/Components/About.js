import React from "react";
// import Doctor from "../Assets/doctor-group.png";
import SolutionStep from "./SolutionStep";
import "../Styles/About.css";

function About() {
  return (
    <div className="about-section" id="about">
      {/* <div className="about-image-content">
        <img src={Doctor} alt="Doctor Group" className="about-image1" />
      </div> */}

      <div className="about-text-content">
        <h3 className="about-title">
          <span>About Us</span>
        </h3>
        <p className="about-description">
          Welcome to Healofy, your trusted partner for accessible and
          personalized self help. Our platform offers online consultations
          and self care options, prioritizing your well-being. Join us on
          this journey towards a healthier you.
        </p>

        <h4 className="about-text-title">What all we offer</h4>

        <SolutionStep
          title="Enjoy wide range of blogs"
          description="Find your perfect blog and posts with ease at Healofy. Expert blogs to prioritize your health, offering tailored self care."
        />

        <SolutionStep
          title="Have a laugh"
          description="Enjoy the jokes and videos that will be provided to you for uplifting your mood."
        />

        <SolutionStep
          title="Get help from experts"
          description="Our experienced doctors and specialists are here to provide expert advice and personalized help, helping you achieve your best possible well-being."
        />
      </div>
    </div>
  );
}

export default About;
