import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./Pages/Home";
import Legal from "./Pages/Legal";
import NotFound from "./Pages/NotFound";
import Appointment from "./Pages/Appointment";
import Adlogin from "./Components/Adlogin";
import Doclogin from "./Components/Doclogin";
import Docsignup from "./Components/Docsignup";
import Login from "./Pages/Login";
import Loginsignup from "./Pages/Loginsignup";


function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route exact path="/Healofy" element={<Home />} />
          <Route path="/legal" element={<Legal />} />
          <Route path="/appointment" element={<Appointment />} />
          <Route path="*" element={<NotFound />} />
          <Route path="/adlogin" element={<Adlogin />} />
          <Route path="/doclogin" element={<Doclogin />} />
          <Route path="/docsignup" element={<Docsignup />} />
          <Route path="/signin" element={<Login />} />
          <Route path="/signup" element={<Loginsignup />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
