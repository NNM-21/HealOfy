export const customerReviews = [
    {
      "name": "Esther Howard",
      "location": "Texas, USA",
      "message": "Healofy transformed my self care experience! The online consultations were so convenient, and the doctors were knowledgeable and caring."
    },
    {
      "name": "John Doe",
      "location": "California, USA",
      "message": "I found the perfect cure for my condition through Healofy. The blogs, posts and jokes made me feel so much better. Thank you for prioritizing my health!"
    },
    {
      "name": "Alice Smith",
      "location": "New York, USA",
      "message": "Booking appointments was a breeze, and the service exceeded my expectations. The doctors truly listen and provide effective solutions. 5 stars!"
    },
    {
      "name": "Bob Johnson",
      "location": "Florida, USA",
      "message": "Healofy is a game-changer! The emergency care saved me during a critical situation. Grateful for their quick and efficient support."
    },
    {
      "name": "Jane Brown",
      "location": "Washington, USA",
      "message": "I used to dread psychiatric visits, but Healofy made it a pleasant experience. The psychiatrist was gentle and professional. I'll definitely be back!"
    }
    
];
